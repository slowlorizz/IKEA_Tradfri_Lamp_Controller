#ifndef WIFISECRETS_H
#define WIFISECRETS_H

#include <Arduino.h>

struct WifiSecrets {
    static constexpr char* WifiSSID = "tuxnet2";
    static constexpr char* WifiPassword = "0erlik0n14!X";
};

#endif
